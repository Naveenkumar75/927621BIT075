/* eslint-disable no-unused-vars */
// src/components/ProductDetail.js

import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { getProducts } from '../api';
import {
  Card,
  CardContent,
  CardMedia,
  Typography,
  Container,
  CircularProgress,
} from '@mui/material';

const ProductDetail = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    const fetchProduct = async () => {
      const products = await getProducts(); // Fetch all products initially
      const foundProduct = products.find((p) => p.id === id);
      setProduct(foundProduct);
    };
    fetchProduct();
  }, [id]);

  if (!product) {
    return (
      <Container>
        <CircularProgress />
      </Container>
    );
  }

  return (
    <Container>
      <Card>
        <CardMedia
          component="img"
          alt={product.name}
          height="400"
          image={`https://picsum.photos/600?random=${product.id}`}
        />
        <CardContent>
          <Typography variant="h4" component="div">
            {product.name}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Company: {product.company}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Category: {product.category}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Price: ${product.price}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Rating: {product.rating}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Discount: {product.discount}%
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Availability: {product.availability ? 'In Stock' : 'Out of Stock'}
          </Typography>
        </CardContent>
      </Card>
    </Container>
  );
};

export default ProductDetail;