/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
// src/components/ProductList.js

import React, { useState, useEffect } from 'react';
import { getProducts } from '../api';
import { Link } from 'react-router-dom';
import {
  Card,
  CardContent,
  CardMedia,
  Typography,
  Grid,
  Container,
  MenuItem,
  Select,
  TextField,
  Button,
} from '@mui/material';

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [category, setCategory] = useState('');
  const [company, setCompany] = useState('');
  const [rating, setRating] = useState('');
  const [priceRange, setPriceRange] = useState([0, 1000]);
  const [availability, setAvailability] = useState('');
  const [sort, setSort] = useState('');

  useEffect(() => {
    const fetchProducts = async () => {
      const data = await getProducts(category, company);
      setProducts(data);
    };
    fetchProducts();
  }, [category, company]);

  const handleSortChange = (event) => {
    const sortedProducts = [...products];
    const sortType = event.target.value;
    setSort(sortType);

    switch (sortType) {
      case 'price':
        sortedProducts.sort((a, b) => a.price - b.price);
        break;
      case 'rating':
        sortedProducts.sort((a, b) => b.rating - a.rating);
        break;
      case 'discount':
        sortedProducts.sort((a, b) => b.discount - a.discount);
        break;
      default:
        break;
    }
    setProducts(sortedProducts);
  };

  return (
    <Container>
      <Typography variant="h4" gutterBottom>
        Products
      </Typography>
      <Grid container spacing={2} justifyContent="space-between">
        <Grid item>
          <TextField
            label="Category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          />
        </Grid>
        <Grid item>
          <TextField
            label="Company"
            value={company}
            onChange={(e) => setCompany(e.target.value)}
          />
        </Grid>
        <Grid item>
          <TextField
            label="Rating"
            type="number"
            value={rating}
            onChange={(e) => setRating(e.target.value)}
          />
        </Grid>
        <Grid item>
          <TextField
            label="Price Range"
            value={priceRange.join('-')}
            onChange={(e) => setPriceRange(e.target.value.split('-').map(Number))}
          />
        </Grid>
        <Grid item>
          <Select value={sort} onChange={handleSortChange}>
            <MenuItem value="price">Sort by Price</MenuItem>
            <MenuItem value="rating">Sort by Rating</MenuItem>
            <MenuItem value="discount">Sort by Discount</MenuItem>
          </Select>
        </Grid>
        <Grid item>
          <Button variant="contained" color="primary" onClick={() => fetchProducts()}>
            Filter
          </Button>
        </Grid>
      </Grid>
      <Grid container spacing={4} style={{ marginTop: '20px' }}>
        {products.map((product) => (
          <Grid item key={product.id} xs={12} sm={6} md={4}>
            <Card>
              <CardMedia
                component="img"
                alt={product.name}
                height="140"
                image={`https://picsum.photos/200?random=${product.id}`}
              />
              <CardContent>
                <Typography variant="h5" component="div">
                  {product.name}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Company: {product.company}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Category: {product.category}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Price: ${product.price}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Rating: {product.rating}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Discount: {product.discount}%
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Availability: {product.availability ? 'In Stock' : 'Out of Stock'}
                </Typography>
                <Button component={Link} to={`/product/${product.id}`} variant="contained" color="primary">
                  View Details
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default ProductList;