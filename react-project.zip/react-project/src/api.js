import axios from "axios";

const BASE_URL ="http://20.244.56.144/test/companies/:companyname/categories/categoryname/products?top=n&minPrice=p&maxPrice=q";

export const getProducts = async (category, company) => {
  try {
    const response = await axios.get(`${BASE_URL}/products`, {
      params: { category, company },
    });
    return response.data;
  } catch (error) {
    console.error("Error fetching products:", error);
    return [];
  }
};
